from django.apps import AppConfig


class UconnectAppConfig(AppConfig):
    name = 'Uconnect_app'
