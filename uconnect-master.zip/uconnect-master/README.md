# uconnect
repository for uconnect

U-connect is a social platform for university students to connect with the community of their choice.
Connect with people of your domain. Provide services to others and get free or paid services of your choice.
